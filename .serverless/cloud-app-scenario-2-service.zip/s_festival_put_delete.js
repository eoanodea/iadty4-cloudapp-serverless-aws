
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'eoanod',
  applicationName: 'cloud-app-scenario-2',
  appUid: 'DvtdW64dnTxXmJD2hS',
  orgUid: 'bf89a863-1a57-4863-8bcf-f6c2ed72047d',
  deploymentUid: '88d4f6a3-7b0c-4e89-8d6d-353c42714dcb',
  serviceName: 'cloud-app-scenario-2-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'cloud-app-scenario-2-service-dev-festival_put_delete', timeout: 6 };

try {
  const userHandler = require('./controllers/festival/put_delete.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}